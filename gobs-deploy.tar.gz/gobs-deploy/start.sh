#!/bin/bash
set -e
DEPLOY_DIR="$HOME/gobs"

echo "=== 1. 安装后端依赖 ==="
cd "$DEPLOY_DIR/backend"
npm install --production --legacy-peer-deps

echo "=== 2. 配置 Nginx ==="
sudo cp "$DEPLOY_DIR/nginx.conf" /etc/nginx/sites-available/gobs
sudo ln -sf /etc/nginx/sites-available/gobs /etc/nginx/sites-enabled/gobs
sudo rm -f /etc/nginx/sites-enabled/default
sudo nginx -t && sudo systemctl reload nginx

echo "=== 3. 启动后端 (pm2) ==="
cd "$DEPLOY_DIR/backend"
pm2 delete gobs-api 2>/dev/null || true
pm2 start dist/index.js --name gobs-api
pm2 save

echo ""
echo "=== 部署完成 ==="
echo "访问地址：http://49.235.61.68"
